package com.example.myrestfulservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyRestfulServicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
