package com.example.myrestfulservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyRestfulServicesApplication {

    public static void main(String[] args) {

        SpringApplication.run(MyRestfulServicesApplication.class, args);
    }

}
