package com.example.myrestfulservices;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class ArithmeticOperationBean {
    private int result;
    private String message;
}
