package com.example.myrestfulservices;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
//lombok
public class helloWorldBean {
    private String message;
}
